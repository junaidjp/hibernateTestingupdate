package com.junaid.Hibernate;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateTesting

{	


	  public static void main(String[] args) {
	    Session session = null;

	    try{
	    

	     // SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	      
	      SessionFactory sessionFactory=HibernateSessionFactory.getSessionFactory();
	       session =sessionFactory.openSession();
	       org.hibernate.Transaction tx = 
	    	   session.beginTransaction();
	         System.out.println("Inserting Record");
	        UserBean HB = new UserBean();
	      //  HB.setId(2);
	        HB.setUsername("Venkat");
	        HB.setPassword("J2ee Trainee");
	        session.save(HB);	 
	        tx.commit();
	        System.out.println("Done");
	        
	        // How to load the Objects 
	        UserBean userBean = (UserBean) session.load(UserBean.class, 1);
	        System.out.println(userBean.getId()+ " " + userBean.getPassword()+ " " +userBean.getUsername());
	        
	        //how to Load All Objects 
	        
	        Query result = session.createQuery("from UserBean");
	        
	         List<UserBean>  userbeanList= result.list();
	         for (UserBean usr : userbeanList) { 
	        	 System.out.println(usr.getId());
	        	 System.out.println(usr.getUsername());
	        	 System.out.println(usr.getPassword());
	         }
	         
	    }catch(Exception e){
	      System.out.println(e.getMessage());
	    }finally{
	      // Actual contact insertion will happen at this step
	      session.flush();
	      session.close();

	      }
	    
	  }
	  
	  
	  
	  
	} 
	

